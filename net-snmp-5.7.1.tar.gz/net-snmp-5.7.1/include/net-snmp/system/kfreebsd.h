#include "freebsd6.h"
#define freebsd6 freebsd6

#include <osreldate.h>
#define __FreeBSD_version __FreeBSD_kernel_version

#include <sys/queue.h>
#include <sys/_types.h>

